Welcome To Eaglercraft 1.21.1! Please Click Fork Because This Repo May Not Be Here Long!
TeaVM Port Of Minecraft 1.21.1!


Pros:
Has Shadersmod!
Has New Blocks!



Cons:
Might Be Laggy!
Does not have a lot of code yet!
TeaVM may have got stuff incorrect!
No Login Screen!
